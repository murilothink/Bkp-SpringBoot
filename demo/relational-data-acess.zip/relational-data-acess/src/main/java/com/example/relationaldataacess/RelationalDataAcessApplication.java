package com.example.relationaldataacess;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RelationalDataAcessApplication {

	public static void main(String[] args) {
		SpringApplication.run(RelationalDataAcessApplication.class, args);
	}

}
